(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_90f72504._.js",
  "static/chunks/node_modules_recharts_es6_3fa6f35d._.js",
  "static/chunks/node_modules_b27b7aba._.js",
  "static/chunks/src_77b85d72._.js"
],
    source: "dynamic"
});
