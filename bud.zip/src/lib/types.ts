
export type TransactionType = 'income' | 'expense';

export const Categories = [
  "Food", "Travel", "Bills", "Entertainment", "Shopping",
  "Groceries", "Utilities", "Salary", "Freelance", "Investment", "Other"
] as const;

export type Category = typeof Categories[number];

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: Category;
  date: string; // ISO string
  description: string;
  // linkedGoalId is removed as budgeting is now category-based
}

export interface UserProfile {
  name: string;
  email: string;
}

// SavingsGoal interface is removed. We'll use a new type for category budgets directly in the context.

export interface CategoryBudget {
  category: Category;
  targetAmount: number; // User-defined monthly target for this category
}
