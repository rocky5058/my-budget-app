
"use client";

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  LayoutDashboard,
  ArrowLeftRight,
  UserCircle,
  Menu,
  Coins,
  Star,
  LayoutGrid, // Changed icon for Category Budgets
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
}

const navItems: NavItem[] = [
  { href: '/', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/transactions', label: 'Transactions', icon: ArrowLeftRight },
  { href: '/category-budgets', label: 'Category Budgets', icon: LayoutGrid }, // Updated href and label
  { href: '/premium', label: 'Upgrade Plan', icon: Star },
  { href: '/profile', label: 'Profile', icon: UserCircle },
];

const AppShell = ({ children }: { children: React.ReactNode }) => {
  const pathname = usePathname();
  const [isMobile, setIsMobile] = useState(false);
  const [pageTitle, setPageTitle] = useState('Dashboard');

  useEffect(() => {
    const currentNavItem = navItems.find(item => item.href === pathname);
    if (currentNavItem) {
      setPageTitle(currentNavItem.label);
    } else if (pathname === '/') {
      setPageTitle('Dashboard');
    }
  }, [pathname]);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
      <div className="p-4 border-b border-sidebar-border">
        <Link href="/" className="flex items-center gap-2">
          <Coins className="h-8 w-8 text-primary" />
          <h1 className="text-2xl font-headline font-bold text-primary">Budget Tracker</h1>
        </Link>
      </div>
      <nav className="flex-grow p-4 space-y-2">
        {navItems.map((item) => (
          <Button
            key={item.href}
            variant={pathname === item.href ? 'default' : 'ghost'}
            className={`w-full justify-start text-base ${
              pathname === item.href 
                ? 'bg-primary text-primary-foreground hover:bg-primary/90' 
                : 'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
            }`}
            asChild
          >
            <Link href={item.href}>
              <item.icon className="mr-3 h-5 w-5" />
              {item.label}
            </Link>
          </Button>
        ))}
      </nav>
      <div className="p-4 border-t border-sidebar-border">
        <p className="text-xs text-center text-sidebar-foreground/70">&copy; 2024 Budget Tracker</p>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-background">
      {isMobile ? (
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="fixed top-4 left-4 z-50">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72 bg-sidebar">
            <SidebarContent />
          </SheetContent>
        </Sheet>
      ) : (
        <aside className="w-64 fixed top-0 left-0 h-full shadow-lg z-10">
           <SidebarContent />
        </aside>
      )}
      <main className={`flex-1 flex flex-col overflow-auto ${isMobile ? 'pt-16' : 'ml-64'}`}>
        <header className={`p-4 shadow-md bg-card ${isMobile ? 'fixed top-0 left-0 right-0 z-40' : ''}`}>
          <h2 className={`text-2xl font-headline font-semibold text-card-foreground ${isMobile ? 'ml-12' : ''}`}>{pageTitle}</h2>
        </header>
        <div className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
};

export default AppShell;
