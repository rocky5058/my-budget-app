
"use client";
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useTransactions } from '@/contexts/TransactionContext'; 
import type { Category } from '@/lib/types';
import { Categories } from '@/lib/types';
import { getMonth, getYear } from 'date-fns';
import { Edit3, Save, XCircle, LayoutGrid } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface CategoryBudgetCardProps {
  category: Category;
  targetAmount: number;
  spentAmount: number;
  onUpdateTarget: (newTarget: number) => void;
}

const CategoryBudgetCard: React.FC<CategoryBudgetCardProps> = ({ category, targetAmount, spentAmount, onUpdateTarget }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editingTarget, setEditingTarget] = useState(targetAmount);
  const { toast } = useToast();

  const remainingAmount = targetAmount - spentAmount;
  const progressPercentage = targetAmount > 0 ? Math.min(100, (spentAmount / targetAmount) * 100) : 0;

  let status: 'On Track' | 'Approaching Limit' | 'Over Budget' | 'Not Set' = 'Not Set';
  let statusColor = 'text-muted-foreground';
  let progressColor = 'bg-primary'; // Default progress bar color

  if (targetAmount > 0) {
    if (spentAmount > targetAmount) {
      status = 'Over Budget';
      statusColor = 'text-red-500';
      progressColor = 'bg-red-500';
    } else if (spentAmount >= targetAmount * 0.8) {
      status = 'Approaching Limit';
      statusColor = 'text-orange-500';
      progressColor = 'bg-orange-500';
    } else {
      status = 'On Track';
      statusColor = 'text-green-500';
    }
  } else {
     status = 'Not Set'; // Or 'Budget Not Set'
     statusColor = 'text-muted-foreground';
  }


  const handleSave = () => {
    onUpdateTarget(editingTarget);
    setIsEditing(false);
    toast({ title: "Target Updated", description: `Target for ${category} set to \$${editingTarget.toLocaleString()}`});
  };

  const handleCancel = () => {
    setEditingTarget(targetAmount);
    setIsEditing(false);
  }

  return (
    <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="font-headline text-xl">{category}</CardTitle>
          <LayoutGrid className="h-6 w-6 text-primary" />
        </div>
        <CardDescription className="text-sm">Monthly budget for {category}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow space-y-3">
        {isEditing ? (
          <div className="space-y-2">
            <Label htmlFor={`target-${category}`}>Set Target Amount ($)</Label>
            <div className="flex items-center gap-2">
              <Input 
                id={`target-${category}`}
                type="number" 
                value={editingTarget} 
                onChange={(e) => setEditingTarget(parseFloat(e.target.value) || 0)}
                className="w-full"
              />
            </div>
          </div>
        ) : (
          <div>
            <p className="text-sm text-muted-foreground">Target: <span className="font-semibold text-foreground">\${targetAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></p>
          </div>
        )}
        <p className="text-sm text-muted-foreground">Spent: <span className="font-semibold text-foreground">\${spentAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></p>
        <p className={`text-sm font-semibold ${remainingAmount < 0 ? 'text-red-500' : 'text-green-600'}`}>
          Remaining: \${remainingAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </p>
        <div>
          <Progress value={progressPercentage} className={`w-full h-3 mb-1 ${progressColor}`} />
          <p className="text-xs text-primary text-right">
            {progressPercentage.toFixed(1)}% of target spent
          </p>
        </div>
      </CardContent>
      <CardFooter className="pt-3 mt-auto flex flex-col items-stretch gap-2">
         <div className="flex justify-between items-center w-full">
            <span className="text-sm font-medium">Status:</span>
            <span className={`text-sm font-semibold ${statusColor}`}>{status}</span>
        </div>
        {isEditing ? (
          <div className="flex gap-2 mt-2">
            <Button onClick={handleSave} size="sm" className="flex-1 bg-green-500 hover:bg-green-600 text-white">
              <Save className="mr-2 h-4 w-4" /> Save
            </Button>
            <Button onClick={handleCancel} variant="outline" size="sm" className="flex-1">
              <XCircle className="mr-2 h-4 w-4" /> Cancel
            </Button>
          </div>
        ) : (
          <Button onClick={() => setIsEditing(true)} variant="outline" size="sm" className="w-full mt-2">
            <Edit3 className="mr-2 h-4 w-4" /> Edit Target
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default function CategoryBudgetsPage() {
  const { categoryBudgets, updateCategoryTarget, getSpentAmountForCategoryMonth } = useTransactions(); 
  const currentDate = new Date();
  const currentMonth = getMonth(currentDate);
  const currentYear = getYear(currentDate);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-center gap-4">
        <div>
          <h2 className="text-3xl font-headline font-semibold">Category Budgets</h2>
          <p className="text-muted-foreground">
            Set and track your monthly spending targets for each category.
          </p>
        </div>
      </div>
      
      {categoryBudgets.length === 0 ? (
        <Card className="shadow-lg">
          <CardContent className="pt-6">
            <div className="text-center text-muted-foreground py-12 flex flex-col items-center">
              <LayoutGrid className="h-16 w-16 text-muted-foreground/50 mb-4" />
              <p className="text-lg mb-2">No budget categories found.</p>
              <p className="text-sm">This might be an issue with context initialization or no categories defined.</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
          {Categories.map((category) => {
            const budget = categoryBudgets.find(b => b.category === category) || { category, targetAmount: 0 };
            const spentAmount = getSpentAmountForCategoryMonth(category, currentMonth, currentYear);
            
            return (
              <CategoryBudgetCard
                key={category}
                category={category}
                targetAmount={budget.targetAmount}
                spentAmount={spentAmount}
                onUpdateTarget={(newTarget) => updateCategoryTarget(category, newTarget)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}
