
"use client";

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Zap, BarChartBig, BrainCircuit, ShieldCheck } from "lucide-react";

const premiumFeatures = [
  {
    icon: Zap,
    title: "AI-Powered Budgeting",
    description: "Get smart suggestions and automated budget creation based on your spending habits.",
  },
  {
    icon: BarChartBig,
    title: "Advanced Reporting",
    description: "Unlock detailed financial reports, custom charts, and trend analysis.",
  },
  {
    icon: BrainCircuit,
    title: "Personalized Insights",
    description: "Receive tailored financial advice and tips to achieve your goals faster.",
  },
  {
    icon: ShieldCheck,
    title: "Priority Support",
    description: "Get faster, dedicated support from our expert team.",
  },
];

export default function PremiumPage() {
  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <Card className="shadow-xl overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-primary to-accent p-8 text-center">
          <div className="flex justify-center mb-4">
            <Zap className="h-16 w-16 text-primary-foreground animate-pulse" />
          </div>
          <CardTitle className="font-headline text-4xl text-primary-foreground">
            Unlock Premium Power
          </CardTitle>
          <CardDescription className="text-xl text-primary-foreground/90 mt-2">
            Supercharge your financial journey with exclusive features.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 md:p-8">
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {premiumFeatures.map((feature, index) => (
              <div key={index} className="flex items-start space-x-4 p-4 bg-muted/50 rounded-lg">
                <feature.icon className="h-8 w-8 text-primary mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-foreground">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center">
            <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground text-lg px-8 py-6 shadow-lg transform hover:scale-105 transition-transform">
              Upgrade to Premium Now
            </Button>
            <p className="text-xs text-muted-foreground mt-3">
              Plans start at just $9.99/month. Cancel anytime.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Why Go Premium?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-muted-foreground">
            <p>Our Premium Plan is designed to provide you with advanced tools and personalized insights, helping you manage your money more effectively and reach your financial goals with greater confidence.</p>
            <p>Experience the full potential of Budget Tracker and take control of your financial future today!</p>
        </CardContent>
      </Card>
    </div>
  );
}
