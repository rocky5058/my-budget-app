
// This page has been moved to /src/app/category-budgets/page.tsx
// to reflect the change from "Savings Goals" to "Category Budgets".
// This file can be safely deleted.
// Keeping it with this comment to signify its replacement.
