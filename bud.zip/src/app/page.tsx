
"use client";
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useTransactions } from "@/contexts/TransactionContext";
import { DollarSign, TrendingUp, TrendingDown, Palette } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, Sector } from 'recharts';
import type { Category } from '@/lib/types';

const DataCard = ({ title, value, icon: Icon, description, currency = true }: { title: string, value: number, icon: React.ElementType, description?: string, currency?: boolean }) => (
  <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-5 w-5 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className={`text-2xl font-bold ${value < 0 ? 'text-destructive' : ''}`}>
        {currency ? `\$${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : value}
      </div>
      {description && <p className="text-xs text-muted-foreground">{description}</p>}
    </CardContent>
  </Card>
);

const renderActiveShape = (props: any) => {
  const RADIAN = Math.PI / 180;
  const { cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + (outerRadius + 10) * cos;
  const sy = cy + (outerRadius + 10) * sin;
  const mx = cx + (outerRadius + 30) * cos;
  const my = cy + (outerRadius + 30) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * 22;
  const ey = my;
  const textAnchor = cos >= 0 ? 'start' : 'end';

  return (
    <g>
      <text x={cx} y={cy} dy={8} textAnchor="middle" fill={fill} className="font-headline text-lg">
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} textAnchor={textAnchor} fill="#333">{`\$${value.toLocaleString('en-US')}`}</text>
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} dy={18} textAnchor={textAnchor} fill="#999">
        {`(Rate ${(percent * 100).toFixed(2)}%)`}
      </text>
    </g>
  );
};


export default function DashboardPage() {
  const { 
    balance, 
    currentMonthIncome, 
    currentMonthExpense, 
    getMonthlySpendingPerCategory,
    getRecentMonthlySummaries 
  } = useTransactions();

  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  
  const [activeIndex, setActiveIndex] = useState(0);

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  const monthlySpendingData = getMonthlySpendingPerCategory(currentMonth, currentYear);
  const incomeExpenseChartData = getRecentMonthlySummaries(3); // Get last 3 months data
  
  const PIE_COLORS = ['#29ABE2', '#F2994A', '#82ca9d', '#ffc658', '#FF8042', '#00C49F', '#FFBB28'];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <DataCard title="Current Balance" value={balance} icon={DollarSign} description="Total available funds" />
        <DataCard title="Income This Month" value={currentMonthIncome} icon={TrendingUp} description="All earnings this month" />
        <DataCard title="Expenses This Month" value={currentMonthExpense} icon={TrendingDown} description="All spending this month" />
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="font-headline">Income vs. Expenses Trend</CardTitle>
          <CardDescription>Comparison for the last 3 months</CardDescription>
        </CardHeader>
        <CardContent className="h-[350px]">
          <ResponsiveContainer width="100%" height="100%">
            {incomeExpenseChartData.length === 0 || incomeExpenseChartData.every(d => d.income === 0 && d.expense === 0) ? (
              <div className="flex items-center justify-center h-full text-muted-foreground">No income/expense data for recent months.</div>
            ) : (
              <BarChart data={incomeExpenseChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis tickFormatter={(value) => `\$${value.toLocaleString('en-US')}`} />
                <Tooltip formatter={(value: number) => `\$${value.toLocaleString('en-US')}`} />
                <Legend />
                <Bar dataKey="income" fill="hsl(var(--chart-1))" name="Income" />
                <Bar dataKey="expense" fill="hsl(var(--chart-2))" name="Expense" />
              </BarChart>
            )}
          </ResponsiveContainer>
        </CardContent>
      </Card>
      
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="font-headline">Spending by Category</CardTitle>
          <CardDescription>Breakdown for {new Date(currentYear, currentMonth).toLocaleString('default', { month: 'long', year: 'numeric' })}</CardDescription>
        </CardHeader>
        <CardContent className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            {monthlySpendingData.length === 0 ? (
               <div className="flex items-center justify-center h-full text-muted-foreground">No spending data for this month.</div>
            ) : (
              <PieChart>
                <Pie
                  activeIndex={activeIndex}
                  activeShape={renderActiveShape}
                  data={monthlySpendingData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  fill="hsl(var(--primary))"
                  dataKey="value"
                  onMouseEnter={onPieEnter}
                  nameKey="name"
                >
                  {monthlySpendingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number, name: string) => [`\$${value.toLocaleString('en-US')}`, name]}/>
              </PieChart>
            )}
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
