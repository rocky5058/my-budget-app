
"use client";

import React, { useState, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { useTransactions } from '@/contexts/TransactionContext';
import type { TransactionType, Category, Transaction } from '@/lib/types';
import { Categories } from '@/lib/types';
import { useToast } from "@/hooks/use-toast";
import { categorizeExpense } from '@/ai/flows/categorize-expense';

const formSchema = z.object({
  type: z.enum(['income', 'expense']),
  amount: z.coerce.number().positive({ message: 'Amount must be positive' }),
  category: z.custom<Category>(val => Categories.includes(val as Category), {
    message: "Invalid category selected",
  }),
  date: z.date(),
  description: z.string().min(1, { message: 'Description is required' }),
});

type TransactionFormData = z.infer<typeof formSchema>;

interface TransactionFormProps {
  closeModal: () => void;
}

export default function TransactionForm({ closeModal }: TransactionFormProps) {
  const { addTransaction } = useTransactions(); // Removed savingsGoals
  const { toast } = useToast();
  const [isCategorizing, setIsCategorizing] = useState(false);

  const { control, handleSubmit, register, watch, setValue, formState: { errors, isSubmitting } } = useForm<TransactionFormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: 'expense',
      amount: 0,
      category: 'Food', // Default category
      date: new Date(),
      description: '',
    },
  });

  const descriptionValue = watch('description');
  const transactionType = watch('type');

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    if (descriptionValue && descriptionValue.length > 3 && transactionType === 'expense') {
      setIsCategorizing(true);
      timeoutId = setTimeout(async () => {
        try {
          const result = await categorizeExpense({ transactionDescription: descriptionValue });
          if (result.category && Categories.includes(result.category as Category)) {
            setValue('category', result.category as Category, { shouldValidate: true });
            toast({ title: "AI Suggestion", description: `Category set to "${result.category}" based on description.` });
          }
        } catch (error) {
          console.error("AI categorization failed:", error);
          toast({ title: "AI Error", description: "Could not suggest a category.", variant: "destructive" });
        } finally {
          setIsCategorizing(false);
        }
      }, 1000);
    } else {
      setIsCategorizing(false);
    }
    return () => clearTimeout(timeoutId);
  }, [descriptionValue, transactionType, setValue, toast]);


  const onSubmit = (data: TransactionFormData) => {
    const transactionPayload: Omit<Transaction, 'id'> = {
        type: data.type,
        amount: data.amount,
        category: data.category,
        date: data.date.toISOString(),
        description: data.description,
    };
    
    addTransaction(transactionPayload);
    toast({
      title: "Transaction Added",
      description: `${data.type.charAt(0).toUpperCase() + data.type.slice(1)} of \$${data.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} for ${data.category} added successfully.`,
    });
    closeModal();
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 py-2">
      <div className="space-y-2">
        <Label>Type</Label>
        <Controller
          name="type"
          control={control}
          render={({ field }) => (
            <RadioGroup
              onValueChange={field.onChange}
              defaultValue={field.value}
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="income" id="income" />
                <Label htmlFor="income">Income</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="expense" id="expense" />
                <Label htmlFor="expense">Expense</Label>
              </div>
            </RadioGroup>
          )}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Amount ($)</Label>
        <Input id="amount" type="number" step="0.01" {...register('amount')} placeholder="e.g. 50.00" />
        {errors.amount && <p className="text-sm text-destructive">{errors.amount.message}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="category">Category</Label>
        <div className="flex items-center gap-2">
          <Controller
            name="category"
            control={control}
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {Categories.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
          {isCategorizing && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
        </div>
        {errors.category && <p className="text-sm text-destructive">{errors.category.message}</p>}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="date">Date</Label>
        <Controller
          name="date"
          control={control}
          render={({ field }) => (
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={`w-full justify-start text-left font-normal ${!field.value && "text-muted-foreground"}`}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={field.value}
                  onSelect={field.onChange}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          )}
        />
        {errors.date && <p className="text-sm text-destructive">{errors.date.message}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Input id="description" {...register('description')} placeholder="e.g. Monthly Salary or Groceries" />
        {errors.description && <p className="text-sm text-destructive">{errors.description.message}</p>}
      </div>

      <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" disabled={isSubmitting || isCategorizing}>
        {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
        Add Transaction
      </Button>
    </form>
  );
}
