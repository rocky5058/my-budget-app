
"use client";

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import TransactionForm from "./components/TransactionForm";
import TransactionList from "./components/TransactionList";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { useTransactions } from '@/contexts/TransactionContext';

export default function TransactionsPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { transactions } = useTransactions();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-headline font-semibold">Transactions</h2>
        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <PlusCircle className="mr-2 h-5 w-5" /> Add Transaction
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[480px]">
            <DialogHeader>
              <DialogTitle className="font-headline text-2xl">Add New Transaction</DialogTitle>
              <DialogDescription>
                Enter the details of your income or expense.
              </DialogDescription>
            </DialogHeader>
            <TransactionForm closeModal={() => setIsModalOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>
      
      <TransactionList transactions={transactions} />
    </div>
  );
}
