
"use client";
import type { Transaction, Category, UserProfile, CategoryBudget } from '@/lib/types';
import { Categories } from '@/lib/types';
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { format, subMonths, startOfMonth, endOfMonth, getMonth, getYear } from 'date-fns';

interface MonthlySummary {
  name: string; // e.g., "Jun 2024"
  income: number;
  expense: number;
}

interface TransactionContextType {
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  balance: number;
  currentMonthIncome: number;
  currentMonthExpense: number;
  overallTotalIncome: number;
  overallTotalExpense: number;
  profile: UserProfile;
  updateProfile: (profile: UserProfile) => void;
  getTransactionsByCategory: (category: Category) => Transaction[];
  getMonthlySpendingPerCategory: (month: number, year: number) => { name: Category, value: number }[];
  getRecentMonthlySummaries: (count?: number) => MonthlySummary[];
  categoryBudgets: CategoryBudget[];
  updateCategoryTarget: (category: Category, targetAmount: number) => void;
  getSpentAmountForCategoryMonth: (category: Category, month: number, year: number) => number;
}

const TransactionContext = createContext<TransactionContextType | undefined>(undefined);

const LOCAL_STORAGE_TRANSACTIONS_KEY = 'budgetTrackerTransactions';
const LOCAL_STORAGE_PROFILE_KEY = 'budgetTrackerProfile';
const LOCAL_STORAGE_CATEGORY_BUDGETS_KEY = 'budgetTrackerCategoryBudgets';

export const TransactionProvider = ({ children }: { children: ReactNode }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [profile, setProfile] = useState<UserProfile>({ name: 'Guest User', email: 'guest@example.com' });
  const [categoryBudgets, setCategoryBudgets] = useState<CategoryBudget[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  const [balance, setBalance] = useState(0);
  const [currentMonthIncome, setCurrentMonthIncome] = useState(0);
  const [currentMonthExpense, setCurrentMonthExpense] = useState(0);
  const [overallTotalIncome, setOverallTotalIncome] = useState(0);
  const [overallTotalExpense, setOverallTotalExpense] = useState(0);
  const [recentMonthlySummaries, setRecentMonthlySummaries] = useState<MonthlySummary[]>([]);

  useEffect(() => {
    const storedTransactions = localStorage.getItem(LOCAL_STORAGE_TRANSACTIONS_KEY);
    if (storedTransactions) {
      setTransactions(JSON.parse(storedTransactions));
    }
    const storedProfile = localStorage.getItem(LOCAL_STORAGE_PROFILE_KEY);
    if (storedProfile) {
      setProfile(JSON.parse(storedProfile));
    }
    const storedCategoryBudgets = localStorage.getItem(LOCAL_STORAGE_CATEGORY_BUDGETS_KEY);
    if (storedCategoryBudgets) {
      const parsedBudgets = JSON.parse(storedCategoryBudgets) as CategoryBudget[];
      // Ensure all categories have a budget entry, add if missing
      const updatedBudgets = Categories.map(cat => {
        const existing = parsedBudgets.find(b => b.category === cat);
        return existing || { category: cat, targetAmount: 0 };
      });
      setCategoryBudgets(updatedBudgets);
    } else {
      // Initialize with default 0 targets if nothing in local storage
      setCategoryBudgets(Categories.map(cat => ({ category: cat, targetAmount: 0 })));
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(LOCAL_STORAGE_TRANSACTIONS_KEY, JSON.stringify(transactions));

      const now = new Date();
      const currentMonth = now.getMonth();
      const currentYear = now.getFullYear();

      let newBalance = 0;
      let newOverallIncome = 0;
      let newOverallExpense = 0;
      let newCurrentMonthIncome = 0;
      let newCurrentMonthExpense = 0;

      transactions.forEach(t => {
        const tDate = new Date(t.date);
        if (t.type === 'income') {
          newBalance += t.amount;
          newOverallIncome += t.amount;
          if (tDate.getMonth() === currentMonth && tDate.getFullYear() === currentYear) {
            newCurrentMonthIncome += t.amount;
          }
        } else {
          newBalance -= t.amount;
          newOverallExpense += t.amount;
          if (tDate.getMonth() === currentMonth && tDate.getFullYear() === currentYear) {
            newCurrentMonthExpense += t.amount;
          }
        }
      });
      setBalance(newBalance);
      setOverallTotalIncome(newOverallIncome);
      setOverallTotalExpense(newOverallExpense);
      setCurrentMonthIncome(newCurrentMonthIncome);
      setCurrentMonthExpense(newCurrentMonthExpense);

      const summaries: MonthlySummary[] = [];
      for (let i = 2; i >= 0; i--) {
        const targetDate = subMonths(now, i);
        const month = targetDate.getMonth();
        const year = targetDate.getFullYear();
        let monthIncome = 0;
        let monthExpense = 0;
        transactions.forEach(t => {
          const tDate = new Date(t.date);
          if (tDate.getMonth() === month && tDate.getFullYear() === year) {
            if (t.type === 'income') monthIncome += t.amount;
            else monthExpense += t.amount;
          }
        });
        summaries.push({
          name: format(targetDate, 'MMM yyyy'),
          income: monthIncome,
          expense: monthExpense,
        });
      }
      setRecentMonthlySummaries(summaries);
    }
  }, [transactions, isLoaded]);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(LOCAL_STORAGE_PROFILE_KEY, JSON.stringify(profile));
    }
  }, [profile, isLoaded]);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(LOCAL_STORAGE_CATEGORY_BUDGETS_KEY, JSON.stringify(categoryBudgets));
    }
  }, [categoryBudgets, isLoaded]);

  const addTransaction = (transactionData: Omit<Transaction, 'id'>) => {
    const newTransaction = { ...transactionData, id: uuidv4() };
    setTransactions(prev => [newTransaction, ...prev].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    // No direct update to categoryBudgets here as they are targets; spent amounts are derived.
  };

  const updateProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
  };

  const updateCategoryTarget = (categoryToUpdate: Category, newTargetAmount: number) => {
    setCategoryBudgets(prevBudgets =>
      prevBudgets.map(budget =>
        budget.category === categoryToUpdate
          ? { ...budget, targetAmount: Math.max(0, newTargetAmount) } // Ensure target is not negative
          : budget
      )
    );
  };

  const getTransactionsByCategory = (category: Category): Transaction[] => {
    return transactions.filter(t => t.category === category);
  };

  const getMonthlySpendingPerCategory = (month: number, year: number): { name: Category, value: number }[] => {
    const categoryMap = new Map<Category, number>();
    transactions
      .filter(t => {
        const tDate = new Date(t.date);
        return t.type === 'expense' && tDate.getMonth() === month && tDate.getFullYear() === year;
      })
      .forEach(t => {
        categoryMap.set(t.category, (categoryMap.get(t.category) || 0) + t.amount);
      });
    return Array.from(categoryMap.entries()).map(([name, value]) => ({ name, value }));
  };
  
  const getRecentMonthlySummaries = (count: number = 3): MonthlySummary[] => {
    return recentMonthlySummaries;
  };

  const getSpentAmountForCategoryMonth = (category: Category, month: number, year: number): number => {
    return transactions
      .filter(t => {
        const tDate = new Date(t.date);
        return t.type === 'expense' && t.category === category && tDate.getMonth() === month && tDate.getFullYear() === year;
      })
      .reduce((sum, t) => sum + t.amount, 0);
  };

  if (!isLoaded) {
    return null; 
  }

  return (
    <TransactionContext.Provider value={{
      transactions,
      addTransaction,
      balance,
      currentMonthIncome,
      currentMonthExpense,
      overallTotalIncome,
      overallTotalExpense,
      profile,
      updateProfile,
      getTransactionsByCategory,
      getMonthlySpendingPerCategory,
      getRecentMonthlySummaries,
      categoryBudgets,
      updateCategoryTarget,
      getSpentAmountForCategoryMonth,
    }}>
      {children}
    </TransactionContext.Provider>
  );
};

export const useTransactions = (): TransactionContextType => {
  const context = useContext(TransactionContext);
  if (context === undefined) {
    throw new Error('useTransactions must be used within a TransactionProvider');
  }
  return context;
};
