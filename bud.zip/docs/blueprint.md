# **App Name**: FinTrack AI

## Core Features:

- Transaction Entry: Manual income and expense entry with amount, category, date, and description.
- Graphical Dashboard: Display of monthly spending via line charts, bar graphs, and pie charts for category analysis and income vs expense comparison.
- AI-Powered Expense Categorization: Based on transaction descriptions and user history, suggests relevant spending categories; acts as a tool to save the user time when adding transactions.
- User Profile Management: A display that allows the user to view basic data about their account; also enables editing basic info
- Savings Goals Display: Displays monthly savings suggestions based on user behavior.

## Style Guidelines:

- Primary color: A vibrant blue (#29ABE2) to convey trust and innovation.
- Background color: Light, desaturated blue (#E5F6FD) for a clean, calming backdrop.
- Accent color: A contrasting orange (#F2994A) to highlight key actions and data points.
- Body and headline font: 'PT Sans', a humanist sans-serif offering a balance of modernity and warmth for a user-friendly experience.
- Simple, modern icons for categories, transactions, and navigation.
- Clean and intuitive layout with clear visual hierarchy and easy navigation.
- Subtle transitions and animations to enhance user experience without being distracting.